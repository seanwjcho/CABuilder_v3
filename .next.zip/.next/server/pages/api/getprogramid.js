"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getprogramid";
exports.ids = ["pages/api/getprogramid"];
exports.modules = {

/***/ "mysql2/promise":
/*!*********************************!*\
  !*** external "mysql2/promise" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ "(api)/./pages/api/getprogramid.js":
/*!***********************************!*\
  !*** ./pages/api/getprogramid.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"mysql2/promise\");\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    const dbconnection = await mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createConnection({\n        host: \"localhost\",\n        database: \"javabase\",\n        port: \"3306\",\n        user: \"java\",\n        password: \"javapassword\"\n    });\n    if (req.method == \"POST\") {\n        try {\n            const query = \"SELECT * FROM programs\";\n            const values = [];\n            const [data] = await dbconnection.execute(query, values);\n            console.log(data);\n            console.log(\"queried programids!\");\n            return res.status(200).json({\n                id: data\n            });\n        } catch (error) {\n            console.log(\"error, not queried\");\n            return res.status(500).json({\n                id: \"\"\n            });\n        }\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0cHJvZ3JhbWlkLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFvQztBQUNyQixlQUFlQyxPQUFPLENBQUNDLEdBQUcsRUFBRUMsR0FBRyxFQUFDO0lBRTNDLE1BQU1DLFlBQVksR0FBRyxNQUFNSixzRUFBdUIsQ0FBQztRQUMvQ00sSUFBSSxFQUFFLFdBQVc7UUFDakJDLFFBQVEsRUFBRSxVQUFVO1FBQ3BCQyxJQUFJLEVBQUMsTUFBTTtRQUNYQyxJQUFJLEVBQUMsTUFBTTtRQUNYQyxRQUFRLEVBQUMsY0FBYztLQUMxQixDQUFDO0lBR0YsSUFBSVIsR0FBRyxDQUFDUyxNQUFNLElBQUksTUFBTSxFQUFFO1FBQ3RCLElBQUk7WUFDQSxNQUFNQyxLQUFLLEdBQUcsd0JBQXdCO1lBQ3RDLE1BQU1DLE1BQU0sR0FBRyxFQUFFO1lBQ2pCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsTUFBTVYsWUFBWSxDQUFDVyxPQUFPLENBQUNILEtBQUssRUFBRUMsTUFBTSxDQUFDO1lBQ3hERyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDLENBQUM7WUFDbEJFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUM7WUFFbkMsT0FBT2QsR0FBRyxDQUFDZSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztnQkFBQ0MsRUFBRSxFQUFFTixJQUFJO2FBQUMsQ0FBQyxDQUFDO1NBQzNDLENBQUMsT0FBT08sS0FBSyxFQUFFO1lBQ1pMLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsT0FBT2QsR0FBRyxDQUFDZSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztnQkFBQ0MsRUFBRSxFQUFFLEVBQUU7YUFBQyxDQUFDLENBQUM7U0FDekM7S0FDSjtDQU9KIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2dldHByb2dyYW1pZC5qcz8yNTZjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBteXNxbDIgZnJvbSBcIm15c3FsMi9wcm9taXNlXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpe1xyXG5cclxuICAgIGNvbnN0IGRiY29ubmVjdGlvbiA9IGF3YWl0IG15c3FsMi5jcmVhdGVDb25uZWN0aW9uKHtcclxuICAgICAgICBob3N0OiBcImxvY2FsaG9zdFwiLFxyXG4gICAgICAgIGRhdGFiYXNlOiBcImphdmFiYXNlXCIsXHJcbiAgICAgICAgcG9ydDpcIjMzMDZcIixcclxuICAgICAgICB1c2VyOlwiamF2YVwiLFxyXG4gICAgICAgIHBhc3N3b3JkOlwiamF2YXBhc3N3b3JkXCJcclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBpZiAocmVxLm1ldGhvZCA9PSBcIlBPU1RcIikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gXCJTRUxFQ1QgKiBGUk9NIHByb2dyYW1zXCI7XHJcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xyXG4gICAgICAgICAgICBjb25zdCBbZGF0YV0gPSBhd2FpdCBkYmNvbm5lY3Rpb24uZXhlY3V0ZShxdWVyeSwgdmFsdWVzKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicXVlcmllZCBwcm9ncmFtaWRzIVwiKTtcclxuICAgICAgICBcclxuICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtpZDogZGF0YX0pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IsIG5vdCBxdWVyaWVkXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLmpzb24oe2lkOiBcIlwifSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgXHJcblxyXG4gICAgXHJcblxyXG5cclxufSJdLCJuYW1lcyI6WyJteXNxbDIiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiZGJjb25uZWN0aW9uIiwiY3JlYXRlQ29ubmVjdGlvbiIsImhvc3QiLCJkYXRhYmFzZSIsInBvcnQiLCJ1c2VyIiwicGFzc3dvcmQiLCJtZXRob2QiLCJxdWVyeSIsInZhbHVlcyIsImRhdGEiLCJleGVjdXRlIiwiY29uc29sZSIsImxvZyIsInN0YXR1cyIsImpzb24iLCJpZCIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/getprogramid.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getprogramid.js"));
module.exports = __webpack_exports__;

})();