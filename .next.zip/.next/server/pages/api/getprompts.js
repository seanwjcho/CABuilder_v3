"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getprompts";
exports.ids = ["pages/api/getprompts"];
exports.modules = {

/***/ "mysql2/promise":
/*!*********************************!*\
  !*** external "mysql2/promise" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ "(api)/./pages/api/getprompts.js":
/*!*********************************!*\
  !*** ./pages/api/getprompts.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"mysql2/promise\");\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    const dbconnection = await mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createConnection({\n        host: \"localhost\",\n        database: \"javabase\",\n        port: \"3306\",\n        user: \"java\",\n        password: \"javapassword\"\n    });\n    if (req.method == \"POST\") {\n        try {\n            const query = \"SELECT prompt_id, prompt_text FROM prompts WHERE program_id = ?\";\n            const values = [\n                req.body\n            ];\n            const [data] = await dbconnection.execute(query, values);\n            return res.status(200).json({\n                prompts: data\n            });\n        } catch (error) {\n            console.log(\"error, not queried\");\n            return res.status(500).json({\n                prompts: \"\"\n            });\n        }\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0cHJvbXB0cy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBb0M7QUFDckIsZUFBZUMsT0FBTyxDQUFDQyxHQUFHLEVBQUVDLEdBQUcsRUFBQztJQUUzQyxNQUFNQyxZQUFZLEdBQUcsTUFBTUosc0VBQXVCLENBQUM7UUFDL0NNLElBQUksRUFBRSxXQUFXO1FBQ2pCQyxRQUFRLEVBQUUsVUFBVTtRQUNwQkMsSUFBSSxFQUFDLE1BQU07UUFDWEMsSUFBSSxFQUFDLE1BQU07UUFDWEMsUUFBUSxFQUFDLGNBQWM7S0FDMUIsQ0FBQztJQUdGLElBQUlSLEdBQUcsQ0FBQ1MsTUFBTSxJQUFJLE1BQU0sRUFBRTtRQUN0QixJQUFJO1lBQ0EsTUFBTUMsS0FBSyxHQUFHLGlFQUFpRTtZQUMvRSxNQUFNQyxNQUFNLEdBQUc7Z0JBQUNYLEdBQUcsQ0FBQ1ksSUFBSTthQUFDO1lBQ3pCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsTUFBTVgsWUFBWSxDQUFDWSxPQUFPLENBQUNKLEtBQUssRUFBRUMsTUFBTSxDQUFDO1lBRXhELE9BQU9WLEdBQUcsQ0FBQ2MsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxJQUFJLENBQUM7Z0JBQUNDLE9BQU8sRUFBRUosSUFBSTthQUFDLENBQUMsQ0FBQztTQUNoRCxDQUFDLE9BQU9LLEtBQUssRUFBRTtZQUNaQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLE9BQU9uQixHQUFHLENBQUNjLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsSUFBSSxDQUFDO2dCQUFDQyxPQUFPLEVBQUUsRUFBRTthQUFDLENBQUMsQ0FBQztTQUM5QztLQUNKO0NBT0oiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9hcGkvZ2V0cHJvbXB0cy5qcz80MDA2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBteXNxbDIgZnJvbSBcIm15c3FsMi9wcm9taXNlXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpe1xyXG5cclxuICAgIGNvbnN0IGRiY29ubmVjdGlvbiA9IGF3YWl0IG15c3FsMi5jcmVhdGVDb25uZWN0aW9uKHtcclxuICAgICAgICBob3N0OiBcImxvY2FsaG9zdFwiLFxyXG4gICAgICAgIGRhdGFiYXNlOiBcImphdmFiYXNlXCIsXHJcbiAgICAgICAgcG9ydDpcIjMzMDZcIixcclxuICAgICAgICB1c2VyOlwiamF2YVwiLFxyXG4gICAgICAgIHBhc3N3b3JkOlwiamF2YXBhc3N3b3JkXCJcclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBpZiAocmVxLm1ldGhvZCA9PSBcIlBPU1RcIikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gXCJTRUxFQ1QgcHJvbXB0X2lkLCBwcm9tcHRfdGV4dCBGUk9NIHByb21wdHMgV0hFUkUgcHJvZ3JhbV9pZCA9ID9cIjtcclxuICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gW3JlcS5ib2R5XTtcclxuICAgICAgICAgICAgY29uc3QgW2RhdGFdID0gYXdhaXQgZGJjb25uZWN0aW9uLmV4ZWN1dGUocXVlcnksIHZhbHVlcyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7cHJvbXB0czogZGF0YX0pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IsIG5vdCBxdWVyaWVkXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLmpzb24oe3Byb21wdHM6IFwiXCJ9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICBcclxuXHJcbiAgICBcclxuXHJcblxyXG59Il0sIm5hbWVzIjpbIm15c3FsMiIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJkYmNvbm5lY3Rpb24iLCJjcmVhdGVDb25uZWN0aW9uIiwiaG9zdCIsImRhdGFiYXNlIiwicG9ydCIsInVzZXIiLCJwYXNzd29yZCIsIm1ldGhvZCIsInF1ZXJ5IiwidmFsdWVzIiwiYm9keSIsImRhdGEiLCJleGVjdXRlIiwic3RhdHVzIiwianNvbiIsInByb21wdHMiLCJlcnJvciIsImNvbnNvbGUiLCJsb2ciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/getprompts.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getprompts.js"));
module.exports = __webpack_exports__;

})();