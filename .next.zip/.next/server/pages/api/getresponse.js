"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getresponse";
exports.ids = ["pages/api/getresponse"];
exports.modules = {

/***/ "mysql2/promise":
/*!*********************************!*\
  !*** external "mysql2/promise" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ "(api)/./pages/api/getresponse.js":
/*!**********************************!*\
  !*** ./pages/api/getresponse.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"mysql2/promise\");\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    const dbconnection = await mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createConnection({\n        host: \"localhost\",\n        database: \"javabase\",\n        port: \"3306\",\n        user: \"java\",\n        password: \"javapassword\"\n    });\n    if (req.method == \"POST\") {\n        try {\n            const query = \"SELECT response_text FROM responses WHERE prompt_id = ?\";\n            const values = [\n                req.body\n            ];\n            const [data] = await dbconnection.execute(query, values);\n            console.log(\"get response\");\n            console.log(data);\n            return res.status(200).json({\n                response: data\n            });\n        } catch (error) {\n            console.log(\"error, not queried\");\n            return res.status(500).json({\n                prompts: \"\"\n            });\n        }\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0cmVzcG9uc2UuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQW9DO0FBQ3JCLGVBQWVDLE9BQU8sQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLEVBQUM7SUFFM0MsTUFBTUMsWUFBWSxHQUFHLE1BQU1KLHNFQUF1QixDQUFDO1FBQy9DTSxJQUFJLEVBQUUsV0FBVztRQUNqQkMsUUFBUSxFQUFFLFVBQVU7UUFDcEJDLElBQUksRUFBQyxNQUFNO1FBQ1hDLElBQUksRUFBQyxNQUFNO1FBQ1hDLFFBQVEsRUFBQyxjQUFjO0tBQzFCLENBQUM7SUFHRixJQUFJUixHQUFHLENBQUNTLE1BQU0sSUFBSSxNQUFNLEVBQUU7UUFDdEIsSUFBSTtZQUNBLE1BQU1DLEtBQUssR0FBRyx5REFBeUQ7WUFDdkUsTUFBTUMsTUFBTSxHQUFHO2dCQUFDWCxHQUFHLENBQUNZLElBQUk7YUFBQztZQUN6QixNQUFNLENBQUNDLElBQUksQ0FBQyxHQUFHLE1BQU1YLFlBQVksQ0FBQ1ksT0FBTyxDQUFDSixLQUFLLEVBQUVDLE1BQU0sQ0FBQztZQUN4REksT0FBTyxDQUFDQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDNUJELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxJQUFJLENBQUMsQ0FBQztZQUVsQixPQUFPWixHQUFHLENBQUNnQixNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztnQkFBQ0MsUUFBUSxFQUFFTixJQUFJO2FBQUMsQ0FBQyxDQUFDO1NBQ2pELENBQUMsT0FBT08sS0FBSyxFQUFFO1lBQ1pMLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsT0FBT2YsR0FBRyxDQUFDZ0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxJQUFJLENBQUM7Z0JBQUNHLE9BQU8sRUFBRSxFQUFFO2FBQUMsQ0FBQyxDQUFDO1NBQzlDO0tBQ0o7Q0FPSiIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzL2FwaS9nZXRyZXNwb25zZS5qcz9mNGRjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBteXNxbDIgZnJvbSBcIm15c3FsMi9wcm9taXNlXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpe1xyXG5cclxuICAgIGNvbnN0IGRiY29ubmVjdGlvbiA9IGF3YWl0IG15c3FsMi5jcmVhdGVDb25uZWN0aW9uKHtcclxuICAgICAgICBob3N0OiBcImxvY2FsaG9zdFwiLFxyXG4gICAgICAgIGRhdGFiYXNlOiBcImphdmFiYXNlXCIsXHJcbiAgICAgICAgcG9ydDpcIjMzMDZcIixcclxuICAgICAgICB1c2VyOlwiamF2YVwiLFxyXG4gICAgICAgIHBhc3N3b3JkOlwiamF2YXBhc3N3b3JkXCJcclxuICAgIH0pO1xyXG5cclxuXHJcbiAgICBpZiAocmVxLm1ldGhvZCA9PSBcIlBPU1RcIikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gXCJTRUxFQ1QgcmVzcG9uc2VfdGV4dCBGUk9NIHJlc3BvbnNlcyBXSEVSRSBwcm9tcHRfaWQgPSA/XCI7XHJcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IFtyZXEuYm9keV07XHJcbiAgICAgICAgICAgIGNvbnN0IFtkYXRhXSA9IGF3YWl0IGRiY29ubmVjdGlvbi5leGVjdXRlKHF1ZXJ5LCB2YWx1ZXMpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCByZXNwb25zZVwiKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7cmVzcG9uc2U6IGRhdGF9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yLCBub3QgcXVlcmllZFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNTAwKS5qc29uKHtwcm9tcHRzOiBcIlwifSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgXHJcblxyXG4gICAgXHJcblxyXG5cclxufSJdLCJuYW1lcyI6WyJteXNxbDIiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiZGJjb25uZWN0aW9uIiwiY3JlYXRlQ29ubmVjdGlvbiIsImhvc3QiLCJkYXRhYmFzZSIsInBvcnQiLCJ1c2VyIiwicGFzc3dvcmQiLCJtZXRob2QiLCJxdWVyeSIsInZhbHVlcyIsImJvZHkiLCJkYXRhIiwiZXhlY3V0ZSIsImNvbnNvbGUiLCJsb2ciLCJzdGF0dXMiLCJqc29uIiwicmVzcG9uc2UiLCJlcnJvciIsInByb21wdHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/getresponse.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getresponse.js"));
module.exports = __webpack_exports__;

})();